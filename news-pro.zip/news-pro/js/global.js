// Don't use .ready() since this file is already loaded in the footer.
(function($) {

    $( '.content, .sidebar' ).matchHeight({
        property: 'min-height'
    });

})(jQuery);
