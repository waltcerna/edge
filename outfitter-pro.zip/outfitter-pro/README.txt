OUTFITTER PRO
https://my.studiopress.com/themes/outfitter/

INSTALL
1. Upload the Outfitter Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Base theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit https://my.studiopress.com/documentation/outfitter-pro-theme/.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Content Site Layout option.
Front Page 1 - This is the front page 1 section.
Front Page 2 - This is the front page 2 section.
Front Page 3 - This is the front page 3 section.
Footer - This is the footer section.
Off-Screen Content - This is the off-screen content section.
After Entry - This is the after entry section.

ICON FONTS
The icons used in the Outfitter Pro theme are free of copyright and courtesy of http://ionicons.com/.

LOCALIZATION
The Outfitter Pro theme is translation ready.  More information about the translation process can be found at http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit https://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.0 =
* Initial release.

= 1.0.1 =
* Improve handling of full-width-narrow body class.
* Remove page.php file.
* Update plugin deactivation check for Genesis Connect for WooCommerce notice.
* Standards and documentation improvements.

= 1.0.2 =
* Update Sale Price display for WooCommerce 3.3+.
* Update image functions for WooCommerce 3.3+.
* Standards improvements.
* Update CSS for Custom HTML widget.
