SIXTEEN NINE PRO THEME
http://my.studiopress.com/themes/sixteen-nine/

INSTALL
1. Upload the Sixteen Nine Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Sixteen Nine Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/sixteen-nine-theme/.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar Site Layout option.
Header Right - This is the widgeted area that appears after the title area section of the header.
After Entry - This is the widget that appears after the entry on single posts.

LOCALIZATION
The Sixteen Nine theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.1 =
* Remove rem units

= 1.1 =
* Move backstretch image upload to customizer
* Enable header text checkbox
* Add theme setting defaults
* Use theme supports for after entry widget
* Update responsive menu
* HTML5 Galleries