MODERN STUDIO PRO THEME
http://my.studiopress.com/themes/modern-studio/

INSTALL
1. Upload the Modern Studio Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Modern Studio Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

WIDGET AREAS
Sticky Message - This is the sticky message widget area.
Welcome Message - This is the welcome message widget area.
After Entry - This is the after entry widget area.
Footer 1 - This is the first column of the footer section.
Footer 2 - This is the second column of the footer section.
Footer 3 - This is the third column of the footer section.

CUSTOM BACKGROUND
This theme supports custom background, which is a native WordPress function.
You can find some really great free textures to use at http://subtlepatterns.com.

CHANGELOG

= 1.0 =
* Initial release

= 1.0.1 =
* Solid Simple Social Icons style

= 1.0.2 =
* Update CSS for Genesis Simple Share button changes
* Remove Comment form allowed tags filter
* Post Password style
* Remove unused nav extras setting

= 1.0.3 =
* Remove IE8 CSS fix for images
* Add hr tag styling
* Add small and disabled button styles
* Update menu names in admin