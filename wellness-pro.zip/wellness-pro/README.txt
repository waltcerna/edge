WELLNESS PRO
http://my.studiopress.com/themes/wellness/

INSTALL
1. Upload the Wellness Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Wellness theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/documentation/wellness-pro-theme/.

WIDGET AREAS
Header Right - This is the widgeted area that appears after the title area section of the header.
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Conent Site Layout option.
Sticky Message - This is the sticky message section that appears on the front page.
Front Page 1 - This is the front page 1 widget area.
Front Page 2 - This is the front page 2 widget area.
Front Page 3 - This is the front page 3 widget area.
Front Page 4 - This is the front page 4 widget area.
Front Page 5 - This is the front page 5 widget area.
Front Page 6 - This is the front page 6 widget area.
Before Footer - This is the before footer widget area.
Footer - This is the footer widget area.
After Entry - This is the after entry widget area.

LOCALIZATION
The Wellness Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.0 =
* Initial release

= 1.0.1 =
* Widen Author Pro archive pages
* Image section background image scroll
* Move Sticky Message hook to front page conditional
* Remove deprecated theme tags

= 1.0.2 =
* Update documentation

= 1.1.0 =
* Add WooCommerce support and styling
* Update file structure
* Update responsive menu
* Update text domain

= 1.1.1 =
* Fix focus styling issue on search form submit button
* Fix minor WooCommerce styling issues
* Update conditionals for loading matchHeight on WooCommerce pages
* Update mobile menu submenu label

= 1.1.2 =
* Fix error thrown when WooCommerce was inactive

= 1.1.3 =
* Fix product gallery bug in WooCommerce 3.0 update
* Fix product archive display

= 1.1.4 =
* Update WooCommerce responsive CSS
* Update flexible widgets to work with customizer
* Update responsive menu to 1.1.3
* Update carrot display on dropdown menus
