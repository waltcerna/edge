BEAUTIFUL PRO THEME
http://my.studiopress.com/themes/beautiful/

INSTALL
1. Upload the Beautiful Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Beautiful Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/beautiful-theme/.

WIDGET AREAS
Header Right - This is the widgeted area that appears after the title area section of the header.
Before Header - This is the before header widget area.
Welcome Message - This is the welcome message widget area.
After Entry - This is the after entry widget area.
Split Sidebar Left - This is the left split sidebar widget area.
Split Sidebar Right - This is the right split sidebar widget area.
Bottom Sidebar - This is the bottom sidebar widget area.

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.1 =
* Remove rem units

= 1.0.2 =
* Add theme setting defaults

= 1.1 =
* Update theme setting defaults
* Use theme supports for after entry widget
* Update mobile menu
* HTML5 Galleries