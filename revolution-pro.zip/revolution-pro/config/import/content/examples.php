<?php
/**
 * Revolution Pro.
 *
 * Page Examples page content optionally installed after theme activation.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Revolution Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution/
 */

return <<<CONTENT
<!-- wp:paragraph {"align":"left"} -->
<p style="text-align:left">We've included several homepage content examples as shown on the theme demo. To update the page assigned as the homepage, go to Appearance > Customize > Homepage settings and select your desired page for the homepage.</p>
<!-- /wp:paragraph -->
CONTENT;
