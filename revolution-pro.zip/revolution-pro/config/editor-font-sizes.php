<?php
/**
 * Revolution Pro child theme editor font sizes.
 *
 * @package Revolution Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution/
 */

/**
 * Editor font sizes config.
 */
return array(
	array(
		'name' => __( 'Small', 'revolution-pro' ),
		'size' => 14,
		'slug' => 'small',
	),
	array(
		'name' => __( 'Normal', 'revolution-pro' ),
		'size' => 18,
		'slug' => 'normal',
	),
	array(
		'name' => __( 'Large', 'revolution-pro' ),
		'size' => 20,
		'slug' => 'large',
	),
	array(
		'name' => __( 'Larger', 'revolution-pro' ),
		'size' => 24,
		'slug' => 'larger',
	),
);
