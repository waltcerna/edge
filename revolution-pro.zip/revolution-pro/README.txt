Revolution Pro Theme
https://my.studiopress.com/themes/revolution/

INSTALL
1. Upload the Revolution Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the theme & use Genesis Onboarding to Create your new homepage.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. For additional instructions, please visit https://my.studiopress.com/documentation/revolution-pro-theme/.

Visit example.com/wp-admin/admin.php?page=genesis-getting-started to restart the theme onboarding wizard, if desired.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Content Site Layout option.
Footer 1 - This is the footer 1 widget section.
Footer 2 - This is the footer 2 widget section.
After Entry - This is the after entry section.

LOCALIZATION
The Revolution Pro theme is translation ready.

SUPPORT
Please visit https://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.1.3 =
* Changed: Update imported plugin information to include "Third Party" for relevant plugins.
* Changed: Update theme tags to include block-related tags.

= 1.1.2 =
* Changed: Correct class names for theme primary and secondary colors.

= 1.1.1 =
* Changed: Block editor color style slugs to allow for better theme interoperability.

= 1.1.0 =
Revolution Pro 1.1.0 requires Genesis 2.9 or higher.

* Import homepage variations and additional sample pages during One-Click Theme Setup.
* Set up menus during One-Click Theme Setup. Menu items will point to imported sample content.
* Remove import XML file. Sample pages can be imported when first activating the theme from the Appearance -> Themes area, or by visiting `/wp-admin/admin.php?page=genesis-getting-started` if the theme is already active.
* Install and activate dependent plugins WPForms Lite, Genesis eNews Extended, and Simple Social Icons (in addition to Atomic Blocks) during One-Click Theme Setup.
* Fix outline button styling.
* Make second menu appear below the first menu at mobile widths, instead of above it.
* Improvements to coding standards.

= 1.0.0 =
* Initial release.