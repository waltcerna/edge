<?php
/**
 * Revolution Pro.
 *
 * This file adds the default theme settings to the Revolution Pro Theme.
 *
 * @package Revolution Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution/
 */

add_filter( 'genesis_theme_settings_defaults', 'revolution_theme_defaults' );
/**
 * Updates theme settings when resetting them at Genesis -> Theme Settings.
 *
 * Can be removed when Genesis Theme Settings are removed from WP admin.
 *
 * @since 1.0.0
 *
 * @param array $defaults Original theme settings defaults.
 * @return array Modified defaults.
 */
function revolution_theme_defaults( $defaults ) {

	$args = genesis_get_config( 'child-theme-settings-genesis' );

	return wp_parse_args( $args, $defaults );

}

add_filter( 'simple_social_default_styles', 'revolution_social_default_styles' );
/**
 * Sets Simple Social Icon defaults.
 *
 * @since 1.0.0
 *
 * @param array $defaults Social style defaults.
 * @return array Modified social style defaults.
 */
function revolution_social_default_styles( $defaults ) {

	$args = genesis_get_config( 'simple-social-icons-settings' );

	return wp_parse_args( $args, $defaults );

}
