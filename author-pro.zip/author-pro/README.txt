AUTHOR PRO THEME
http://my.studiopress.com/themes/author/

INSTALL
1. Upload the Author Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Author Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/documentation/author-pro-theme/.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Content Site Layout option.
Front Page 1 - This is the first section of the home page.
Front Page 2 - This is the second section of the home page.
Front Page 3 - This is the third section of the home page.
Front Page 4 - This is the fourth section of the home page.
Front Page 5 - This is the fifth section of the home page.
After Entry - This is the widget that appears after the entry on single posts.
Footer 1 - This is the first column of the footer section.
Footer 2 - This is the second column of the footer section.
Footer 3 - This is the third column of the footer section.

LOCALIZATION
The Author Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.0 =
* Initial release

= 1.1.0 =
* Add Accessibility support

= 1.1.1 =
* Remove deprecated theme tags
* Update documentation

= 1.2.0 =
* Add color contrast detection to the customizer
* Add new responsive menu script
* Add WooCommerce support
* Update file structure
* Update documentation
* Update text domain

= 1.2.1 =
* Fix error thrown when WooCommerce was inactive

= 1.2.3 =
* Fix product gallery bug in WooCommerce 3.0 update
* Update flexible widgets to work with customizer
* Update responsive menu to 1.1.3
* Fix WooCommerce archive description layout
