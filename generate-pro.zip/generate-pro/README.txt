GENERATE PRO THEME
http://my.studiopress.com/themes/generate/

INSTALL
1. Upload the Generate Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Generate Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/generate-theme/.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Content Site Layout option.
Header Right - This is the widgeted area that appears at the top right of the header. If it is active then Genesis style will follow the Partial Header style otherwise it will follow the Full Image Header Style, if image header is selected. 
Home Featured - This is the featured widget area of the home page.
After Entry - This is the widget that appears after the entry on single posts.

FEATURED IMAGES
By default WordPress will create a default thumbnail image for each image you upload and the size can be specified in your dashboard under Settings > Media. In addition, the Generate Pro Theme creates the following thumbnail images you'll see below, which are defined (and can be modified) in the functions.php file. These are the recommended thumbnail sizes that are used on the Generate Pro Theme demo site.

blog - 700px by 300px

LOCALIZATION
The Generate Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

= 2.1 =
* Add theme setting defaults
* Update responsive menu
* Use theme supports for after entry widget
* HTML5 Galleries

= 2.1.1 =
* Remove obsolete comments filter
* Remove IE8 CSS fix for images
* Add hr tag styling
* Add small and disabled button styles
* Update menu names in admin
* Update widget area descriptions