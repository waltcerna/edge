AMBIANCE PRO THEME
http://my.studiopress.com/themes/ambiance/

INSTALL
1. Upload the Ambiance Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Ambiance Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/ambiance-theme/.

WIDGET AREAS
After Entry - This is the widget that appears after the entry on single posts.

ENTRY BACKGROUND IMAGES
The optimal size for an entry background image is 1600px by 900px.
The entry background images that were used in the Ambiance Pro theme demo are courtesy http://www.gratisography.com/.

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0.1 =
* Add theme setting defaults

= 1.1 =
* Add customizer code for Genesis 2.1
* Update theme setting defaults

= 1.1.1 =
* Use theme supports for after entry widget
* HTML5 Galleries